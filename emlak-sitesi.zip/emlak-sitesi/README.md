# Emlak Portalı

A Turkish real estate portal built with HTML, CSS, and JavaScript.

## Features

- Eye-catching banner with search functionality
- Property listing page with filtering and sorting options
- Detailed property pages with specifications, descriptions, and location
- Admin panel for managing property listings
- Mobile-friendly responsive design
- All text content in Turkish

## Pages

1. **Home Page**: Banner, search bar, featured listings, and categories
2. **Listings Page**: Complete property list with extensive filtering options
3. **Property Detail**: Comprehensive view of individual property details
4. **Admin Login**: Secure admin login page
5. **Admin Dashboard**: Complete management of property listings

## Technical Details

- Built with pure HTML, CSS, and JavaScript (no frameworks)
- Mock data for demonstrating property listings
- Mobile-first responsive design
- Local storage for simulating admin login sessions

## Getting Started

Simply open the `index.html` file in a web browser to view the site.

For admin access:
- Username: `admin`
- Password: `emlakportali2024`

## Structure

- `/css`: Style files
- `/js`: JavaScript files
- `/images`: Image assets
- `/admin`: Admin panel pages

## File Details

- `data.js`: Contains mock property listings data
- `main.js`: Core functionality for all pages
- `style.css`: Main stylesheet
- `reset.css`: CSS reset for consistent rendering

## Developer Notes

This project is designed as a demonstration of a real estate website. In a production environment, it would be connected to a backend database and include secure authentication.
