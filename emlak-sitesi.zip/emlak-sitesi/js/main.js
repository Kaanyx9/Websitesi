// Main JavaScript file for Emlak Portal

document.addEventListener('DOMContentLoaded', function() {
    // Initialize mobile menu
    initMobileMenu();

    // Initialize contact popup
    initContactPopup();

    // Initialize districts dropdown
    initDistrictsDropdown();

    // Load property listings
    if (document.getElementById('featured-listings-container')) {
        loadFeaturedListings();
    }

    // If on listing page, load all properties and set up filtering
    if (document.getElementById('all-listings-container')) {
        loadAllListings();
        initFilters();
        initSorting();
    }

    // If on property detail page, load property details
    if (document.getElementById('property-detail-container')) {
        loadPropertyDetail();
    }

    // If on admin login page, set up login form
    if (document.getElementById('admin-login-form')) {
        initAdminLogin();
    }

    // If on admin dashboard, load admin features
    if (document.getElementById('admin-dashboard')) {
        loadAdminDashboard();
    }
});

// Mobile Menu Toggle
function initMobileMenu() {
    const menuToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');

    if (!menuToggle || !mainNav) return;

    menuToggle.addEventListener('click', function() {
        mainNav.classList.toggle('active');
    });

    // Close menu when clicked outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.main-nav') && !event.target.closest('.mobile-menu-toggle')) {
            if (mainNav.classList.contains('active')) {
                mainNav.classList.remove('active');
            }
        }
    });
}

// Contact Popup
function initContactPopup() {
    const contactTriggers = document.querySelectorAll('.contact-trigger');
    const contactPopup = document.getElementById('contact-popup');
    const closePopup = document.getElementById('close-contact');
    const contactForm = document.getElementById('contact-form');

    if (!contactPopup) return;

    contactTriggers.forEach(trigger => {
        trigger.addEventListener('click', function(e) {
            e.preventDefault();
            contactPopup.classList.add('active');
        });
    });

    if (closePopup) {
        closePopup.addEventListener('click', function() {
            contactPopup.classList.remove('active');
        });
    }

    // Close when clicking outside the form
    contactPopup.addEventListener('click', function(e) {
        if (e.target === contactPopup) {
            contactPopup.classList.remove('active');
        }
    });

    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Mesajınız gönderildi. En kısa sürede size dönüş yapacağız.');
            contactPopup.classList.remove('active');
            contactForm.reset();
        });
    }
}

// Initialize districts dropdown based on selected city
function initDistrictsDropdown() {
    const citySelect = document.getElementById('city');
    const districtSelect = document.getElementById('district');

    if (!citySelect || !districtSelect) return;

    citySelect.addEventListener('change', function() {
        const selectedCity = this.value;
        districtSelect.innerHTML = '<option value="">Seçiniz</option>';

        if (selectedCity && locationData[selectedCity]) {
            const districts = locationData[selectedCity].districts;

            districts.forEach(district => {
                const option = document.createElement('option');
                option.value = district.toLowerCase();
                option.textContent = district;
                districtSelect.appendChild(option);
            });

            districtSelect.disabled = false;
        } else {
            districtSelect.innerHTML = '<option value="">Önce il seçiniz</option>';
            districtSelect.disabled = true;
        }
    });
}

// Format price in Turkish Lira format
function formatPrice(price) {
    return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") + " TL";
}

// Load featured listings on home page
function loadFeaturedListings() {
    const container = document.getElementById('featured-listings-container');
    if (!container) return;

    const featuredProperties = propertiesData.filter(property => property.isFeatured);

    if (featuredProperties.length === 0) {
        container.innerHTML = '<p class="no-results">Öne çıkan ilan bulunamadı.</p>';
        return;
    }

    container.innerHTML = '';

    featuredProperties.forEach(property => {
        container.appendChild(createPropertyCard(property));
    });
}

// Load all listings on listings page
function loadAllListings(filteredProperties = null) {
    const container = document.getElementById('all-listings-container');
    if (!container) return;

    const properties = filteredProperties || propertiesData;

    if (properties.length === 0) {
        container.innerHTML = '<p class="no-results">Aradığınız kriterlere uygun ilan bulunamadı.</p>';
        return;
    }

    container.innerHTML = '';

    properties.forEach(property => {
        container.appendChild(createPropertyCard(property));
    });

    // Update results count
    const resultsCount = document.getElementById('results-count');
    if (resultsCount) {
        resultsCount.textContent = properties.length;
    }
}

// Create a property card element
function createPropertyCard(property) {
    const card = document.createElement('div');
    card.className = 'property-card';

    // Determine tag class based on property type
    let tagClass = '';
    let tagText = '';

    switch(property.type) {
        case 'satilik':
            tagClass = 'tag-sale';
            tagText = 'Satılık';
            break;
        case 'kiralik':
            tagClass = 'tag-rent';
            tagText = 'Kiralık';
            break;
        case 'arsa':
            tagClass = 'tag-land';
            tagText = 'Arsa';
            break;
        case 'yeni':
            tagClass = 'tag-sale';
            tagText = 'Yeni Proje';
            break;
    }

    card.innerHTML = `
        <div class="property-image">
            <img src="${property.image}" alt="${property.title}">
            <div class="property-tag ${tagClass}">${tagText}</div>
            <div class="property-price">${formatPrice(property.price)}</div>
        </div>
        <div class="property-content">
            <h3 class="property-title">${property.title}</h3>
            <div class="property-location"><i class="fas fa-map-marker-alt"></i> ${property.location}</div>
            <div class="property-features">
                ${property.area ? `<div class="property-feature"><i class="fas fa-vector-square"></i> ${property.area} m²</div>` : ''}
                ${property.rooms ? `<div class="property-feature"><i class="fas fa-bed"></i> ${property.rooms} Oda</div>` : ''}
                ${property.bathrooms ? `<div class="property-feature"><i class="fas fa-bath"></i> ${property.bathrooms} Banyo</div>` : ''}
            </div>
        </div>
    `;

    // Add click event to navigate to property detail page
    card.addEventListener('click', function() {
        window.location.href = `ilan-detay.html?id=${property.id}`;
    });

    return card;
}

// Initialize property filters
function initFilters() {
    const filterForm = document.getElementById('filter-form');
    if (!filterForm) return;

    const filters = {
        type: document.getElementById('filter-type'),
        category: document.getElementById('filter-category'),
        city: document.getElementById('filter-city'),
        district: document.getElementById('filter-district'),
        minPrice: document.getElementById('filter-min-price'),
        maxPrice: document.getElementById('filter-max-price'),
        minArea: document.getElementById('filter-min-area'),
        maxArea: document.getElementById('filter-max-area'),
        rooms: document.getElementById('filter-rooms')
    };

    // Populate dropdowns
    populateFilterOptions(filters);

    // Apply filters when form is submitted
    filterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        applyFilters(filters);
    });

    // Reset filters
    const resetButton = document.getElementById('reset-filters');
    if (resetButton) {
        resetButton.addEventListener('click', function() {
            filterForm.reset();
            // Reset district dropdown
            if (filters.district) {
                filters.district.innerHTML = '<option value="">Seçiniz</option>';
                filters.district.disabled = true;
            }
            loadAllListings();
        });
    }

    // Get URL parameters and apply them as initial filters
    const urlParams = new URLSearchParams(window.location.search);
    const typeParam = urlParams.get('type');

    if (typeParam && filters.type) {
        filters.type.value = typeParam;
        applyFilters(filters);
    }
}

// Populate filter dropdowns with options
function populateFilterOptions(filters) {
    // Populate property types dropdown
    if (filters.type) {
        propertyTypes.forEach(type => {
            const option = document.createElement('option');
            option.value = type.id;
            option.textContent = type.name;
            filters.type.appendChild(option);
        });
    }

    // Populate property categories dropdown
    if (filters.category) {
        propertyCategories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            filters.category.appendChild(option);
        });
    }

    // Populate cities dropdown
    if (filters.city) {
        Object.keys(locationData).forEach(cityKey => {
            const option = document.createElement('option');
            option.value = cityKey;
            option.textContent = locationData[cityKey].name;
            filters.city.appendChild(option);
        });
    }

    // Populate rooms dropdown
    if (filters.rooms) {
        roomOptions.forEach(room => {
            const option = document.createElement('option');
            option.value = room.id;
            option.textContent = room.name;
            filters.rooms.appendChild(option);
        });
    }
}

// Apply filters to property listings
function applyFilters(filters) {
    let filtered = [...propertiesData];

    // Filter by property type
    if (filters.type && filters.type.value) {
        filtered = filtered.filter(property => property.type === filters.type.value);
    }

    // Filter by property category
    if (filters.category && filters.category.value) {
        filtered = filtered.filter(property => property.category === filters.category.value);
    }

    // Filter by city
    if (filters.city && filters.city.value) {
        const cityName = locationData[filters.city.value].name;
        filtered = filtered.filter(property => property.location.includes(cityName));
    }

    // Filter by district
    if (filters.district && filters.district.value && !filters.district.disabled) {
        filtered = filtered.filter(property => {
            return property.location.toLowerCase().includes(filters.district.value.toLowerCase());
        });
    }

    // Filter by price range
    if (filters.minPrice && filters.minPrice.value) {
        const minPrice = parseInt(filters.minPrice.value);
        filtered = filtered.filter(property => property.price >= minPrice);
    }

    if (filters.maxPrice && filters.maxPrice.value) {
        const maxPrice = parseInt(filters.maxPrice.value);
        filtered = filtered.filter(property => property.price <= maxPrice);
    }

    // Filter by area range
    if (filters.minArea && filters.minArea.value) {
        const minArea = parseInt(filters.minArea.value);
        filtered = filtered.filter(property => property.area >= minArea);
    }

    if (filters.maxArea && filters.maxArea.value) {
        const maxArea = parseInt(filters.maxArea.value);
        filtered = filtered.filter(property => property.area <= maxArea);
    }

    // Filter by number of rooms
    if (filters.rooms && filters.rooms.value) {
        if (filters.rooms.value === "5+") {
            filtered = filtered.filter(property => property.rooms >= 5);
        } else {
            const roomsNum = parseInt(filters.rooms.value.charAt(0));
            filtered = filtered.filter(property => property.rooms === roomsNum);
        }
    }

    // Update listings with filtered results
    loadAllListings(filtered);
}

// Initialize sorting functionality
function initSorting() {
    const sortSelect = document.getElementById('sort-select');
    if (!sortSelect) return;

    sortSelect.addEventListener('change', function() {
        const container = document.getElementById('all-listings-container');
        if (!container) return;

        // Get current listings
        const currentListings = Array.from(container.getElementsByClassName('property-card'));
        const propertiesIds = currentListings.map(card => {
            const link = card.getAttribute('onclick') || '';
            const idMatch = link.match(/id=(\d+)/);
            return idMatch ? parseInt(idMatch[1]) : 0;
        });

        // Get corresponding property objects
        let properties = propertiesIds.map(id => propertiesData.find(prop => prop.id === id)).filter(Boolean);

        // Sort properties
        switch(this.value) {
            case 'newest':
                properties.sort((a, b) => new Date(b.dateAdded) - new Date(a.dateAdded));
                break;
            case 'oldest':
                properties.sort((a, b) => new Date(a.dateAdded) - new Date(b.dateAdded));
                break;
            case 'price-asc':
                properties.sort((a, b) => a.price - b.price);
                break;
            case 'price-desc':
                properties.sort((a, b) => b.price - a.price);
                break;
            case 'area-asc':
                properties.sort((a, b) => a.area - b.area);
                break;
            case 'area-desc':
                properties.sort((a, b) => b.area - a.area);
                break;
        }

        // Update listings with sorted results
        loadAllListings(properties);
    });
}

// Load property details on property detail page
function loadPropertyDetail() {
    const container = document.getElementById('property-detail-container');
    if (!container) return;

    // Get property ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const propertyId = parseInt(urlParams.get('id'));

    if (!propertyId) {
        container.innerHTML = '<p class="error">İlan bulunamadı.</p>';
        return;
    }

    // Find property in data
    const property = propertiesData.find(prop => prop.id === propertyId);

    if (!property) {
        container.innerHTML = '<p class="error">İlan bulunamadı.</p>';
        return;
    }

    // Update page title
    document.title = `${property.title} - Emlak Portalı`;

    // Fill property details
    fillPropertyDetails(property);

    // Initialize Google Maps
    if (property.coordinates) {
        initMap(property.coordinates, property.title);
    }
}

// Fill property details on the detail page
function fillPropertyDetails(property) {
    // Update property title
    const propertyTitle = document.getElementById('property-title');
    if (propertyTitle) propertyTitle.textContent = property.title;

    // Update property location
    const propertyLocation = document.getElementById('property-location');
    if (propertyLocation) propertyLocation.textContent = property.location;

    // Update property price
    const propertyPrice = document.getElementById('property-price');
    if (propertyPrice) propertyPrice.textContent = formatPrice(property.price);

    // Update property type badge
    const propertyType = document.getElementById('property-type');
    if (propertyType) {
        let typeText = '';
        switch(property.type) {
            case 'satilik': typeText = 'Satılık'; break;
            case 'kiralik': typeText = 'Kiralık'; break;
            case 'arsa': typeText = 'Arsa'; break;
            case 'yeni': typeText = 'Yeni Proje'; break;
        }
        propertyType.textContent = typeText;
    }

    // Initialize image gallery with property images
    if (property.images && property.images.length > 0) {
        initImageGallery(property.images);
    } else if (property.image) {
        // Fallback to single image if images array is not available
        initImageGallery([property.image]);
    }

    // Update property description
    const propertyDescription = document.getElementById('property-description');
    if (propertyDescription) propertyDescription.textContent = property.description;

    // Update property specifications
    const specs = {
        area: { element: document.getElementById('property-area'), value: property.area ? `${property.area} m²` : '-' },
        rooms: { element: document.getElementById('property-rooms'), value: property.rooms ? `${property.rooms} Oda` : '-' },
        bathrooms: { element: document.getElementById('property-bathrooms'), value: property.bathrooms ? `${property.bathrooms} Banyo` : '-' },
        floor: { element: document.getElementById('property-floor'), value: property.floor ? `${property.floor}. Kat` : '-' },
        buildingAge: { element: document.getElementById('property-age'), value: property.buildingAge === 0 ? 'Yeni Bina' : `${property.buildingAge} Yaşında` },
        heatingType: { element: document.getElementById('property-heating'), value: property.heatingType || '-' }
    };

    for (const key in specs) {
        if (specs[key].element) {
            specs[key].element.textContent = specs[key].value;
        }
    }

    // Update property features list
    const featuresList = document.getElementById('property-features-list');
    if (featuresList && property.features && property.features.length > 0) {
        featuresList.innerHTML = '';
        property.features.forEach(feature => {
            const li = document.createElement('li');
            li.innerHTML = `<i class="fas fa-check"></i> ${feature}`;
            featuresList.appendChild(li);
        });
    }

    // Update contact information
    if (property.contactInfo) {
        const contactName = document.getElementById('contact-name-display');
        const contactPhone = document.getElementById('contact-phone-display');
        const contactEmail = document.getElementById('contact-email-display');

        if (contactName) contactName.textContent = property.contactInfo.name;
        if (contactPhone) contactPhone.textContent = property.contactInfo.phone;
        if (contactEmail) contactEmail.textContent = property.contactInfo.email;
    }
}

// Initialize image gallery on property detail page
function initImageGallery(images) {
    const galleryContainer = document.getElementById('gallery-container');
    const galleryNav = document.getElementById('gallery-nav');
    const galleryThumbnails = document.getElementById('gallery-thumbnails');
    const prevButton = document.querySelector('.gallery-prev');
    const nextButton = document.querySelector('.gallery-next');

    if (!galleryContainer || !galleryNav || !galleryThumbnails) return;

    // Clear containers
    galleryContainer.innerHTML = '';
    galleryNav.innerHTML = '';
    galleryThumbnails.innerHTML = '';

    // Create slides, dots, and thumbnails
    images.forEach((image, index) => {
        // Create slide
        const slide = document.createElement('div');
        slide.className = 'gallery-slide';
        slide.innerHTML = `<img src="${image}" alt="Property Image ${index + 1}">`;
        galleryContainer.appendChild(slide);

        // Create dot
        const dot = document.createElement('div');
        dot.className = 'gallery-dot';
        if (index === 0) dot.classList.add('active');
        dot.setAttribute('data-index', index);
        galleryNav.appendChild(dot);

        // Create thumbnail
        const thumbnail = document.createElement('div');
        thumbnail.className = 'gallery-thumbnail';
        if (index === 0) thumbnail.classList.add('active');
        thumbnail.setAttribute('data-index', index);
        thumbnail.innerHTML = `<img src="${image}" alt="Thumbnail ${index + 1}">`;
        galleryThumbnails.appendChild(thumbnail);
    });

    // Initialize slider functionality
    let currentIndex = 0;
    const totalImages = images.length;

    // Function to show selected slide
    function showSlide(index) {
        if (index < 0) index = totalImages - 1;
        if (index >= totalImages) index = 0;

        currentIndex = index;
        galleryContainer.style.transform = `translateX(-${index * 100}%)`;

        // Update active dot
        const dots = galleryNav.querySelectorAll('.gallery-dot');
        dots.forEach(dot => dot.classList.remove('active'));
        dots[index].classList.add('active');

        // Update active thumbnail
        const thumbnails = galleryThumbnails.querySelectorAll('.gallery-thumbnail');
        thumbnails.forEach(thumb => thumb.classList.remove('active'));
        thumbnails[index].classList.add('active');

        // Scroll thumbnail into view
        thumbnails[index].scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }

    // Add event listeners to prev/next buttons
    if (prevButton) {
        prevButton.addEventListener('click', () => {
            showSlide(currentIndex - 1);
        });
    }

    if (nextButton) {
        nextButton.addEventListener('click', () => {
            showSlide(currentIndex + 1);
        });
    }

    // Add event listeners to dots
    const dots = galleryNav.querySelectorAll('.gallery-dot');
    dots.forEach(dot => {
        dot.addEventListener('click', function() {
            const index = parseInt(this.getAttribute('data-index'));
            showSlide(index);
        });
    });

    // Add event listeners to thumbnails
    const thumbnails = galleryThumbnails.querySelectorAll('.gallery-thumbnail');
    thumbnails.forEach(thumb => {
        thumb.addEventListener('click', function() {
            const index = parseInt(this.getAttribute('data-index'));
            showSlide(index);
        });
    });

    // Add keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'ArrowLeft') {
            showSlide(currentIndex - 1);
        } else if (e.key === 'ArrowRight') {
            showSlide(currentIndex + 1);
        }
    });

    // Add touch swipe support
    let touchStartX = 0;
    let touchEndX = 0;

    galleryContainer.addEventListener('touchstart', function(e) {
        touchStartX = e.changedTouches[0].screenX;
    });

    galleryContainer.addEventListener('touchend', function(e) {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    });

    function handleSwipe() {
        if (touchEndX < touchStartX) {
            // Swiped left, go to next slide
            showSlide(currentIndex + 1);
        } else if (touchEndX > touchStartX) {
            // Swiped right, go to previous slide
            showSlide(currentIndex - 1);
        }
    }

    // Auto-rotate slides every 5 seconds
    let slideInterval = setInterval(() => {
        showSlide(currentIndex + 1);
    }, 5000);

    // Pause auto-rotation when hovering over gallery
    const galleryElement = document.querySelector('.property-gallery');
    if (galleryElement) {
        galleryElement.addEventListener('mouseenter', () => {
            clearInterval(slideInterval);
        });

        galleryElement.addEventListener('mouseleave', () => {
            slideInterval = setInterval(() => {
                showSlide(currentIndex + 1);
            }, 5000);
        });
    }

    // Show first slide initially
    showSlide(0);
}

// Admin login functionality
function initAdminLogin() {
    const loginForm = document.getElementById('admin-login-form');
    if (!loginForm) return;

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const username = document.getElementById('admin-username').value;
        const password = document.getElementById('admin-password').value;

        if (username === adminCredentials.username && password === adminCredentials.password) {
            // In a real application, you would use secure authentication and session management
            localStorage.setItem('adminLoggedIn', 'true');
            window.location.href = 'admin/dashboard.html';
        } else {
            alert('Kullanıcı adı veya şifre hatalı!');
        }
    });
}

// Load admin dashboard
function loadAdminDashboard() {
    // Check if admin is logged in
    if (!localStorage.getItem('adminLoggedIn')) {
        window.location.href = '../admin.html';
        return;
    }

    // Load listings in admin panel
    loadAdminListings();

    // Set up logout functionality
    const logoutButton = document.getElementById('admin-logout');
    if (logoutButton) {
        logoutButton.addEventListener('click', function() {
            localStorage.removeItem('adminLoggedIn');
            window.location.href = '../admin.html';
        });
    }

    // Set up add new listing form
    initAddListingForm();
}

// Load listings in admin dashboard
function loadAdminListings() {
    const listingsTable = document.getElementById('admin-listings-table');
    if (!listingsTable) return;

    const tableBody = listingsTable.querySelector('tbody');
    if (!tableBody) return;

    tableBody.innerHTML = '';

    propertiesData.forEach(property => {
        const row = document.createElement('tr');

        // Determine property type text
        let typeText = '';
        switch(property.type) {
            case 'satilik': typeText = 'Satılık'; break;
            case 'kiralik': typeText = 'Kiralık'; break;
            case 'arsa': typeText = 'Arsa'; break;
            case 'yeni': typeText = 'Yeni Proje'; break;
        }

        row.innerHTML = `
            <td>${property.id}</td>
            <td>${property.title}</td>
            <td>${property.location}</td>
            <td>${formatPrice(property.price)}</td>
            <td>${typeText}</td>
            <td>${property.dateAdded}</td>
            <td>
                <div class="featured-toggle ${property.isFeatured ? 'active' : ''}" data-id="${property.id}">
                    <div class="toggle-slider"></div>
                </div>
            </td>
            <td>
                <button class="btn-edit" data-id="${property.id}"><i class="fas fa-edit"></i> Düzenle</button>
                <button class="btn-delete" data-id="${property.id}"><i class="fas fa-trash"></i> Sil</button>
            </td>
        `;

        tableBody.appendChild(row);
    });

    // Set up featured toggle functionality
    initFeaturedToggle();

    // Set up edit and delete buttons
    initEditDeleteButtons();
}

// Initialize featured toggle functionality
function initFeaturedToggle() {
    const toggles = document.querySelectorAll('.featured-toggle');

    toggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            this.classList.toggle('active');

            const propertyId = parseInt(this.getAttribute('data-id'));
            const property = propertiesData.find(prop => prop.id === propertyId);

            if (property) {
                property.isFeatured = this.classList.contains('active');
                alert(`İlan ${property.isFeatured ? 'öne çıkarıldı' : 'öne çıkarılması kaldırıldı'}.`);
            }
        });
    });
}

// Initialize edit and delete buttons in admin panel
function initEditDeleteButtons() {
    // Edit buttons
    const editButtons = document.querySelectorAll('.btn-edit');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const propertyId = parseInt(this.getAttribute('data-id'));
            // In a real application, this would open a form to edit the property
            alert(`${propertyId} numaralı ilanı düzenleme formunu açacak.`);
        });
    });

    // Delete buttons
    const deleteButtons = document.querySelectorAll('.btn-delete');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const propertyId = parseInt(this.getAttribute('data-id'));

            if (confirm(`${propertyId} numaralı ilanı silmek istediğinizden emin misiniz?`)) {
                // In a real application, this would delete the property from the database
                alert(`${propertyId} numaralı ilan silindi.`);
                // Reload listings table
                loadAdminListings();
            }
        });
    });
}

// Initialize add new listing form
function initAddListingForm() {
    const addListingForm = document.getElementById('add-listing-form');
    if (!addListingForm) return;

    // Populate form dropdowns
    populateAddListingForm();

    addListingForm.addEventListener('submit', function(e) {
        e.preventDefault();

        // In a real application, this would add a new property to the database
        alert('Yeni ilan kaydedildi. Gerçek uygulamada, bu ilan veritabanına eklenecektir.');
        addListingForm.reset();
    });
}

// Populate add listing form dropdowns
function populateAddListingForm() {
    // Property type dropdown
    const typeSelect = document.getElementById('property-type-input');
    if (typeSelect) {
        propertyTypes.forEach(type => {
            const option = document.createElement('option');
            option.value = type.id;
            option.textContent = type.name;
            typeSelect.appendChild(option);
        });
    }

    // Property category dropdown
    const categorySelect = document.getElementById('property-category-input');
    if (categorySelect) {
        propertyCategories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            categorySelect.appendChild(option);
        });
    }

    // City dropdown
    const citySelect = document.getElementById('property-city-input');
    if (citySelect) {
        Object.keys(locationData).forEach(cityKey => {
            const option = document.createElement('option');
            option.value = cityKey;
            option.textContent = locationData[cityKey].name;
            citySelect.appendChild(option);
        });
    }
}

// Initialize Google Maps on property detail page
function initMap(coordinates, title) {
    const mapContainer = document.getElementById('property-map');
    if (!mapContainer) return;

    // In a real application, this would initialize Google Maps with the property coordinates
    // For this demo, we'll just display a placeholder with the coordinates
    mapContainer.innerHTML = `
        <div class="map-placeholder">
            <p><i class="fas fa-map-marker-alt"></i> Harita konumu: ${coordinates.lat.toFixed(4)}, ${coordinates.lng.toFixed(4)}</p>
            <p class="map-note">Not: Gerçek uygulamada burada Google Maps entegrasyonu yer alacaktır.</p>
        </div>
    `;
}
