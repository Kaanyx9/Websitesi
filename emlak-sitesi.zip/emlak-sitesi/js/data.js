// Mock data for property listings
const propertiesData = [
    {
        id: 1,
        title: "Deniz Manzaralı 3+1 Lüks Daire",
        location: "Kadıköy, İstanbul",
        price: 4500000,
        type: "satilik", // satılık
        category: "daire", // apartment
        image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
        images: [
            "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1533090161767-e6ffed986c88?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1560448205-4d9b3e6bb6db?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1585128792020-803d29415281?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
        ],
        isFeatured: true,
        rooms: 3,
        bathrooms: 2,
        area: 140, // square meters
        floor: 5,
        buildingAge: 2,
        heatingType: "Doğalgaz Kombi",
        description: "Kadıköy'ün kalbinde, deniz manzaralı, yeni yapılmış lüks bir daire. Dairede 3 yatak odası, 2 banyo, geniş bir salon ve modern bir mutfak bulunmaktadır. Site içerisinde yüzme havuzu, spor salonu ve 24 saat güvenlik hizmeti mevcuttur. Metroya ve diğer toplu taşıma olanaklarına yürüme mesafesindedir.",
        features: ["Asansör", "Otopark", "Güvenlik", "Havuz", "Spor Salonu"],
        coordinates: {
            lat: 40.9918,
            lng: 29.0282
        },
        contactInfo: {
            name: "Ahmet Yılmaz",
            phone: "(0532) 123 45 67",
            email: "ahmet@emlakportali.com"
        },
        dateAdded: "2024-03-15"
    },
    {
        id: 2,
        title: "Bahçeli Müstakil Villa",
        location: "Çeşme, İzmir",
        price: 7500000,
        type: "satilik",
        category: "villa",
        image: "https://images.unsplash.com/photo-1602343168117-bb8ffe3e2e9f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
        images: [
            "https://images.unsplash.com/photo-1602343168117-bb8ffe3e2e9f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
        ],
        isFeatured: true,
        rooms: 5,
        bathrooms: 3,
        area: 280,
        floor: 2,
        buildingAge: 5,
        heatingType: "Yerden Isıtma",
        description: "Çeşme'nin en güzel koyunda, denize 500 metre mesafede, özel bahçeli müstakil villa. Villada 5 yatak odası, 3 banyo, geniş bir salon, şömineli oturma odası ve tam donanımlı bir mutfak bulunmaktadır. Özel yüzme havuzu, bahçe ve barbekü alanı mevcuttur. Yazlık veya yıl boyu yaşam için idealdir.",
        features: ["Bahçe", "Havuz", "Şömine", "Barbekü", "Denize Yakın"],
        coordinates: {
            lat: 38.3223,
            lng: 26.3758
        },
        contactInfo: {
            name: "Mehmet Kaya",
            phone: "(0532) 987 65 43",
            email: "mehmet@emlakportali.com"
        },
        dateAdded: "2024-03-10"
    },
    {
        id: 3,
        title: "Kiralık 2+1 Eşyalı Daire",
        location: "Levent, İstanbul",
        price: 12000,
        type: "kiralik", // kiralık (for rent)
        category: "daire",
        image: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
        images: [
            "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1484154218962-a197022b5858?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1554995207-c18c203602cb?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1565183997392-2f6f122e5912?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
        ],
        isFeatured: true,
        rooms: 2,
        bathrooms: 1,
        area: 95,
        floor: 8,
        buildingAge: 10,
        heatingType: "Merkezi Sistem",
        description: "Levent'in prestijli bir sitesinde, tamamen eşyalı 2+1 daire. Dairede kaliteli mobilyalar, beyaz eşyalar ve tam donanımlı bir mutfak bulunmaktadır. Metroya yürüme mesafesinde, güvenlikli site içerisinde yer almaktadır. Minimum 1 yıllık kiralama için uygundur.",
        features: ["Eşyalı", "Asansör", "Güvenlik", "Kapalı Otopark", "Metro Yakın"],
        coordinates: {
            lat: 41.0819,
            lng: 29.0082
        },
        contactInfo: {
            name: "Ayşe Demir",
            phone: "(0532) 456 78 90",
            email: "ayse@emlakportali.com"
        },
        dateAdded: "2024-03-20"
    },
    {
        id: 4,
        title: "Yatırımlık Deniz Manzaralı Arsa",
        location: "Bodrum, Muğla",
        price: 3000000,
        type: "arsa", // arsa (land)
        category: "arsa",
        image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
        images: [
            "https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1524055833042-b6ac7d86ee42?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1464519046765-f6d70676c2a3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
        ],
        isFeatured: true,
        area: 1000, // square meters
        description: "Bodrum Yalıkavak'ta, deniz manzaralı, imarlı arsa. 1000 m² büyüklüğünde, villa inşaatına uygun. Denize kuş uçuşu 800 metre mesafede, yola cepheli. Elektrik, su ve doğalgaz altyapısı mevcut. Yatırım veya villa projesi için mükemmel bir fırsat.",
        features: ["Deniz Manzaralı", "İmarlı", "Yola Cepheli", "Altyapı Hazır"],
        coordinates: {
            lat: 37.1031,
            lng: 27.2890
        },
        contactInfo: {
            name: "Ali Can",
            phone: "(0532) 234 56 78",
            email: "ali@emlakportali.com"
        },
        dateAdded: "2024-02-28"
    },
    {
        id: 5,
        title: "Kelepir 1+1 Stüdyo Daire",
        location: "Konyaaltı, Antalya",
        price: 1200000,
        type: "satilik",
        category: "daire",
        image: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
        images: [
            "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1493809842364-78817add7ffb?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1497366754035-f200968a6e72?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1569624501755-cdd9231d7f66?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
        ],
        isFeatured: false,
        rooms: 1,
        bathrooms: 1,
        area: 55,
        floor: 3,
        buildingAge: 7,
        heatingType: "Klima",
        description: "Antalya Konyaaltı'nda, sahile 10 dakika yürüme mesafesinde 1+1 stüdyo daire. Daire temiz ve bakımlı olup, tadilat gerektirmemektedir. Site içerisinde açık yüzme havuzu ve otopark mevcuttur. Yatırım amaçlı veya yazlık olarak idealdir.",
        features: ["Havuz", "Otopark", "Sahile Yakın", "Klima"],
        coordinates: {
            lat: 36.8892,
            lng: 30.6417
        },
        contactInfo: {
            name: "Zeynep Şahin",
            phone: "(0532) 345 67 89",
            email: "zeynep@emlakportali.com"
        },
        dateAdded: "2024-03-25"
    },
    {
        id: 6,
        title: "Kiralık Ofis Katı",
        location: "Maslak, İstanbul",
        price: 30000,
        type: "kiralik",
        category: "ofis",
        image: "https://images.unsplash.com/photo-1497366811353-6870744d04b2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
        images: [
            "https://images.unsplash.com/photo-1497366811353-6870744d04b2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1497215728101-856f4ea42174?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1531497865144-0464ef8fb9a9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
        ],
        isFeatured: false,
        area: 250,
        floor: 12,
        buildingAge: 3,
        heatingType: "Merkezi Sistem",
        description: "Maslak'ta prestijli bir plaza içerisinde 250 m² ofis katı. Açık plan tasarımlı, modern altyapılı, hazır ofis. Bölünebilir alanlar, toplantı odaları ve mutfak alanı mevcuttur. Metro çıkışına direkt bağlantılıdır. Minimum 2 yıllık kiralama için uygundur.",
        features: ["Açık Plan", "Güvenlik", "Asansör", "Otopark", "Metro Bağlantılı", "Jeneratör"],
        coordinates: {
            lat: 41.1066,
            lng: 29.0210
        },
        contactInfo: {
            name: "Mustafa Öztürk",
            phone: "(0532) 567 89 01",
            email: "mustafa@emlakportali.com"
        },
        dateAdded: "2024-03-05"
    },
    {
        id: 7,
        title: "Yeni Proje: Anadolu Yakası Rezidans",
        location: "Ataşehir, İstanbul",
        price: 3250000,
        type: "yeni", // yeni projeler
        category: "daire",
        image: "https://images.unsplash.com/photo-1460317442991-0ec209397118?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
        images: [
            "https://images.unsplash.com/photo-1460317442991-0ec209397118?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1554469384-e58fac16e23a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1486304873000-235643847519?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1510784722466-f2aa9c52fff6?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1600585152220-90363fe7e115?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
        ],
        isFeatured: false,
        rooms: 2,
        bathrooms: 1,
        area: 110,
        floor: 15,
        buildingAge: 0, // Yeni
        heatingType: "Merkezi Sistem",
        description: "Ataşehir'de yükselen yeni proje! Anadolu Yakası'nın en prestijli yeni rezidans projesi, akıllı ev sistemleri, 7/24 concierge hizmeti, kapalı otopark, spor kompleksi ve çok daha fazlasını sunuyor. Daireler 1+1, 2+1 ve 3+1 seçenekleriyle satışta. 2025 yılında teslim edilecek olan projede lansmana özel fiyatlar ve ödeme koşulları sunulmaktadır.",
        features: ["Akıllı Ev", "Concierge", "Spor Kompleksi", "Kapalı Otopark", "Çocuk Oyun Alanı"],
        coordinates: {
            lat: 40.9907,
            lng: 29.1212
        },
        contactInfo: {
            name: "Cem Yıldırım",
            phone: "(0532) 678 90 12",
            email: "cem@emlakportali.com"
        },
        dateAdded: "2024-03-01"
    },
    {
        id: 8,
        title: "Satılık Dubleks Çatı Katı",
        location: "Nişantaşı, İstanbul",
        price: 8900000,
        type: "satilik",
        category: "daire",
        image: "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
        images: [
            "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1493809842364-78817add7ffb?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1600210492493-0946911123ea?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
        ],
        isFeatured: false,
        rooms: 4,
        bathrooms: 2,
        area: 200,
        floor: 5,
        buildingAge: 12,
        heatingType: "Doğalgaz Kombi",
        description: "Nişantaşı'nın kalbinde, tarihi bir binada bulunan çatı dubleksi. Alt katta geniş bir salon, mutfak ve bir yatak odası; üst katta ise 3 yatak odası ve 2 banyo bulunmaktadır. Terastan şehir manzarası sunmaktadır. Bina dış cephesi yenilenmiş olup, asansörlüdür. Bölgenin en iyi alışveriş ve yeme-içme mekanlarına yürüme mesafesindedir.",
        features: ["Dubleks", "Teras", "Asansör", "Şehir Manzarası", "Merkezi Konum"],
        coordinates: {
            lat: 41.0484,
            lng: 28.9882
        },
        contactInfo: {
            name: "Selin Koç",
            phone: "(0532) 789 01 23",
            email: "selin@emlakportali.com"
        },
        dateAdded: "2024-03-18"
    },
    {
        id: 9,
        title: "Kiralık Deniz Manzaralı Villa",
        location: "Göcek, Muğla",
        price: 45000,
        type: "kiralik",
        category: "villa",
        image: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
        images: [
            "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1581974206967-93856b25aa13?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1600566752355-35792bedcfea?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1566908829550-e6551b00979b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
        ],
        isFeatured: false,
        rooms: 4,
        bathrooms: 3,
        area: 320,
        floor: 2,
        buildingAge: 6,
        heatingType: "Klima",
        description: "Göcek koyunda, denize sıfır konumda lüks villa. 4 yatak odası, 3 banyo, geniş salon ve tam donanımlı mutfak. Özel plaj erişimi, iskele, sonsuzluk havuzu ve bahçe içerisinde. Havaalanına 30 dakika mesafede. Sezonluk veya aylık kiralamalar için uygundur. Fiyat yaz sezonu için geçerlidir, diğer sezonlar için lütfen iletişime geçiniz.",
        features: ["Denize Sıfır", "Özel Plaj", "Havuz", "İskele", "Klima", "Eşyalı"],
        coordinates: {
            lat: 36.7489,
            lng: 28.9376
        },
        contactInfo: {
            name: "Berk Özkan",
            phone: "(0532) 890 12 34",
            email: "berk@emlakportali.com"
        },
        dateAdded: "2024-03-22"
    },
    {
        id: 10,
        title: "Yatırımlık Ticari Arsa",
        location: "Nilüfer, Bursa",
        price: 5500000,
        type: "arsa",
        category: "arsa",
        image: "https://images.unsplash.com/photo-1500916434205-0c77489c6cf7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
        images: [
            "https://images.unsplash.com/photo-1500916434205-0c77489c6cf7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1470770903676-69b98201ea1c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
            "https://images.unsplash.com/photo-1628624747186-a941c476b7ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
        ],
        isFeatured: false,
        area: 2000,
        description: "Bursa Nilüfer'de, ana yol üzerinde ticari imarlı arsa. 2000 m² büyüklüğünde, ticari bina veya AVM projesi için uygun. Şehir merkezine 15 dakika, otoyol bağlantısına 5 dakika mesafede. Elektrik, su ve doğalgaz altyapısı hazır. Yüksek gelişme potansiyeli olan bölgede nadir bir yatırım fırsatı.",
        features: ["Ticari İmarlı", "Ana Yol Üzeri", "Altyapı Hazır", "Yola Cepheli"],
        coordinates: {
            lat: 40.2153,
            lng: 28.9768
        },
        contactInfo: {
            name: "Emre Arslan",
            phone: "(0532) 901 23 45",
            email: "emre@emlakportali.com"
        },
        dateAdded: "2024-02-15"
    }
];

// City and district data for Turkey (il ve ilçe)
const locationData = {
    istanbul: {
        name: "İstanbul",
        districts: ["Kadıköy", "Beşiktaş", "Şişli", "Üsküdar", "Beyoğlu", "Ataşehir", "Maltepe", "Bakırköy", "Levent", "Maslak", "Nişantaşı"]
    },
    ankara: {
        name: "Ankara",
        districts: ["Çankaya", "Keçiören", "Etimesgut", "Yenimahalle", "Mamak", "Altındağ", "Sincan", "Gölbaşı"]
    },
    izmir: {
        name: "İzmir",
        districts: ["Konak", "Bornova", "Karşıyaka", "Çeşme", "Buca", "Gaziemir", "Bayraklı", "Menemen"]
    },
    antalya: {
        name: "Antalya",
        districts: ["Muratpaşa", "Konyaaltı", "Kepez", "Lara", "Alanya", "Manavgat", "Belek", "Kaş", "Kalkan"]
    },
    bursa: {
        name: "Bursa",
        districts: ["Nilüfer", "Osmangazi", "Yıldırım", "Mudanya", "Gemlik", "İnegöl", "Gürsu"]
    },
    mugla: {
        name: "Muğla",
        districts: ["Bodrum", "Marmaris", "Fethiye", "Göcek", "Datça", "Ortaca", "Dalaman", "Köyceğiz"]
    }
};

// Property types (Emlak tipleri)
const propertyTypes = [
    { id: "satilik", name: "Satılık" },
    { id: "kiralik", name: "Kiralık" },
    { id: "arsa", name: "Arsa" },
    { id: "yeni", name: "Yeni Projeler" }
];

// Property categories (Emlak kategorileri)
const propertyCategories = [
    { id: "daire", name: "Daire" },
    { id: "villa", name: "Villa" },
    { id: "mustakil", name: "Müstakil Ev" },
    { id: "arsa", name: "Arsa" },
    { id: "ofis", name: "Ofis" },
    { id: "dukkan", name: "Dükkan" },
    { id: "bina", name: "Bina" }
];

// Room options for filtering
const roomOptions = [
    { id: "1+0", name: "1+0" },
    { id: "1+1", name: "1+1" },
    { id: "2+1", name: "2+1" },
    { id: "3+1", name: "3+1" },
    { id: "4+1", name: "4+1" },
    { id: "5+", name: "5+ Oda" }
];

// Admin credentials - in a real application, this would be stored securely in a database
const adminCredentials = {
    username: "admin",
    password: "emlakportali2024" // This is just for demonstration
};
